*** This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License under the following terms ***


Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.

NonCommercial — You may not use the material for commercial purposes.

ShareAlike — If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.


__________________________________________________________________________


Note : You can use this Template to create derivative work (and I encourage you to do so) as long as it's not monetized (you can put up a link for donation but no paywall to access it, as I did) and as long as you give appropriate credit. 
Same license shall apply to whatever you'll cook using reARK materials/Template. If you modify the Template itself and want to share it, ask me first.

I hope you'll be able to make the most out of it even if it's not perfect. Hoping it will get more Reaper 6.0 Themes and reARK modifications out there. 

Btw if you are doing a reARK Modification, new layout, revamp, etc,... feel free to contact me and I'll try to include your work in the main release (with credits). 

Have fun theming.

- ArKaDaTa






https://arkadata.com/reark-reaper-skin/


